﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            // Obtener la lista de procesos
            var processes = Process.GetProcesses();

            // Lógica para contar los procesos sin gestionar (puedes personalizarla según tus necesidades)
            int processesToManage = processes.Length;

            // Pasa los datos a la vista
            ViewBag.Processes = processes;
            ViewBag.ProcessesToManage = processesToManage;

            return View();
        }

        [HttpPost]
        public IActionResult Borrar(string processName)
        {
            // Lógica para borrar el proceso con el nombre 'processName'
            // ...

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Modificar(string processName)
        {
            // Lógica para modificar el proceso con el nombre 'processName'
            // ...

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Guardar(string processName)
        {
            // Lógica para guardar los cambios en el proceso con el nombre 'processName'
            // ...

            return RedirectToAction("Index");
        }
    }
}